import sys
from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
PY3 = sys.version_info[0] == 3
if PY3:
    from urllib.parse import unquote, quote_plus, unquote_plus, urlencode #python 3
    from urllib.request import Request, urlopen, URLError  # Python 3
else:    
    from urllib import unquote, quote_plus, unquote_plus, urlencode
    from urllib2 import Request, urlopen, URLError # Python 2
import os
import time
import json
plugin = sys.argv[0]
handle = int(sys.argv[1])
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
addonid = addon.getAddonInfo('id')
icon = addon.getAddonInfo('icon')
translate = xbmcvfs.translatePath if PY3 else xbmc.translatePath
profile = translate(addon.getAddonInfo('profile')) if PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
home = translate(addon.getAddonInfo('path')) if PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
fanart_default = os.path.join(home, 'fanart.png')
libs = os.path.join(home, 'libs')
dialog = xbmcgui.Dialog()
sys.path.append(libs)

canais = [('Ancapsu Classic', 'https://www.youtube.com/c/ANCAPSUClassic', 'Videos sobre o Libertarianismo, os males do estado entre outros, narrado por Peter Turguniev')]

def route(f):
    action_f = f.__name__
    params_dict = {}
    param_string = sys.argv[2]
    if param_string:
        split_commands = param_string[param_string.find('?') + 1:].split('&')
        for command in split_commands:
            if len(command) > 0:
                if "=" in command:
                    split_command = command.split('=')
                    key = split_command[0]
                    value = split_command[1]
                    try:
                        key = unquote_plus(key)
                    except:
                        pass
                    try:
                        value = unquote_plus(value)
                    except:
                        pass
                    params_dict[key] = value
                else:
                    params_dict[command] = ""
    action = params_dict.get('action')
    if action is None and action_f == 'main':
        f()
    elif action == action_f:
        f(params_dict)

def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
    if iconimage == '':
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    dialog.notification(heading, message, iconimage, time, sound=sound)

def get_icon(video_id):
    iconimage = "https://img.youtube.com/vi/%s/0.jpg"%video_id
    return iconimage

def get_fanart(video_id):
    fanart = "https://i.ytimg.com/vi/%s/hqdefault.jpg"%video_id
    return fanart

def get_info(video_id):
    iconimage = get_icon(video_id)
    try:
        url = '\x68\x74\x74\x70\x73\x3a\x2f\x2f\x77\x77\x77\x2e\x79\x6f\x75\x74\x75\x62\x65\x2e\x63\x6f\x6d\x2f\x79\x6f\x75\x74\x75\x62\x65\x69\x2f\x76\x31\x2f\x70\x6c\x61\x79\x65\x72\x3f\x76\x69\x64\x65\x6f\x49\x64\x3d\x25\x73\x26\x6b\x65\x79\x3d\x41\x49\x7a\x61\x53\x79\x41\x4f\x5f\x46\x4a\x32\x53\x6c\x71\x55\x38\x51\x34\x53\x54\x45\x48\x4c\x47\x43\x69\x6c\x77\x5f\x59\x39\x5f\x31\x31\x71\x63\x57\x38\x26\x63\x6f\x6e\x74\x65\x6e\x74\x43\x68\x65\x63\x6b\x4f\x6b\x3d\x54\x72\x75\x65\x26\x72\x61\x63\x79\x43\x68\x65\x63\x6b\x4f\x6b\x3d\x54\x72\x75\x65'%video_id
        body = {'context': {'client': {'clientName': 'ANDROID', 'clientVersion': '16.20'}}}
        req = Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        req.add_header('Content-Type', 'application/json')
        req.add_header('accept-language', 'en-US,en')
        jsondata = json.dumps(body)
        jsondataasbytes = jsondata.encode('utf-8')   # needs to be bytes
        #req.add_header('Content-Length', len(jsondataasbytes))
        response = urlopen(req, jsondataasbytes)
        json_html = response.read()
        json_data = json.loads(json_html)
        video_720p = []
        video_480p = []
        video_360p = []
        video_240p = []
        video_144p = []
        videos = json_data.get("streamingData").get("formats")
        title = json_data.get("videoDetails").get("title")
        
        for v in videos:
            if v.get('qualityLabel') == '720p':
                video_720p.append(v.get("url"))
            if v.get('qualityLabel') == '480p':
                video_480p.append(v.get("url"))                            
            if v.get('qualityLabel') == '360p':
                video_360p.append(v.get("url"))
            if v.get('qualityLabel') == '240p':
                video_240p.append(v.get("url"))
            if v.get('qualityLabel') == '144p':
                video_144p.append(v.get("url"))                                 
        if video_720p:
            stream = video_720p[0] + '|User-Agent=Mozilla/5.0'
        elif video_480p:
            stream = video_480p[0] + '|User-Agent=Mozilla/5.0'
        elif video_360p:
            stream = video_360p[0] + '|User-Agent=Mozilla/5.0'
        elif video_240p:
            stream = video_240p[0] + '|User-Agent=Mozilla/5.0'
        elif video_144p:
            stream = video_144p[0] + '|User-Agent=Mozilla/5.0'                                  
    except:
        stream = False
        title = 'unknow'
    return stream,title,iconimage


def SetView(name):
    if name == 'Wall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(500)')
        except:
            pass
    if name == 'List':
        try:
            xbmc.executebuiltin('Container.SetViewMode(50)')
        except:
            pass
    if name == 'Poster':
        try:
            xbmc.executebuiltin('Container.SetViewMode(51)')
        except:
            pass
    if name == 'Shift':
        try:
            xbmc.executebuiltin('Container.SetViewMode(53)')
        except:
            pass
    if name == 'InfoWall':
        try:
            xbmc.executebuiltin('Container.SetViewMode(54)')
        except:
            pass
    if name == 'WideList':
        try:
            xbmc.executebuiltin('Container.SetViewMode(55)')
        except:
            pass
    if name == 'Fanart':
        try:
            xbmc.executebuiltin('Container.SetViewMode(502)')
        except:
            pass


def get_url(params):
    if params:
        url = '%s?%s'%(plugin, urlencode(params))
    else:
        url = ''
    return url


def item(params,folder=True):
    u = get_url(params)
    if not u:
        u = ''
    name = params.get("name")
    if name:
        name = name
    else:
        name = 'Unknow'
    iconimage = params.get("iconimage")
    if not iconimage:
        iconimage = icon
    fanart = params.get("fanart")
    if not fanart:
        fanart = fanart_default
    description = params.get("description")
    if not description:
        description = ''           
    playable = params.get("playable")
    liz = xbmcgui.ListItem(name)
    liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
    if params.get("media"):
        liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})
    else:
        liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})                                                  
    if playable:
        if playable == 'true':
            liz.setProperty('IsPlayable', 'true')
    ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
    return ok

def get_video_id(url):
    video_id = ''
    try:
        video_id = url.split("v=")[1]
    except:
        pass
    return video_id 

def chunks(lista, n):
    for i in range(0, len(lista), n):
        yield lista[i:i + n]  

@route
def main():    
    xbmcplugin.setContent(handle, 'movies')
    for name,url,description in canais:
        item(params={'name': name, 'action': 'open_channel', 'url': url, 'description': description, 'iconimage': icon},folder=True)
    xbmcplugin.endOfDirectory(handle)
    SetView('WideList')


@route
def open_channel(param):
    infoDialog('Aguarde...', iconimage='INFO',time=8000)
    from pytube import Channel,YouTube
    url = param.get('url')
    try:
        page = int(param.get('page'))
    except:
        page = 1
    lista = [v for v in Channel(url)]
    try:
        videos_count = lista[::-1]
    except:
        videos_count = lista
    quant = 10
    array = list(chunks(lista, quant))
    total_page = int(len(array))
    try:
        select_array = array[page - 1 if total_page > 1 else 0]
    except:
        select_array = []
    if select_array:
        for v in select_array:
            title = '%s - %s'%(str(videos_count.index(v) + 1),YouTube(v).title)
            video_id = get_video_id(v)
            iconimage = "https://img.youtube.com/vi/%s/0.jpg"%video_id
            fanart = "https://i.ytimg.com/vi/%s/hqdefault.jpg"%video_id
            item({'name': title, 'action': 'playitem', 'iconimage': iconimage, 'video_id': str(video_id), 'playable': 'true'},folder=False)
    if int(page) + 1 <= total_page and total_page > 1:
        item({'name': 'Pagina ' + str(int(page) + 1) + ' de '+str(total_page), 'action': 'open_channel', 'url': url, 'page': str(int(page) + 1),'iconimage': ''},folder=True)
    xbmcplugin.endOfDirectory(handle)


@route
def playitem(param):
    video_id = param.get('video_id')
    url,name,iconimage = get_info(video_id)
    fanart = iconimage
    liz = xbmcgui.ListItem(name)
    liz.setPath(url)
    liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})
    liz.setInfo(type='video', infoLabels={'Title': name, 'plot': '' })
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)